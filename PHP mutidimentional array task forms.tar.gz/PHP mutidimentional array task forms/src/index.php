<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>M-D Array</title>
</head>

<body>
    <?php

    $details = array(
        "Item" => array(
            "Milk" => array(
                "Q1" => 340,
                "Q2" => 680,
                "Q3" => 535
            ),
            "Egg" => array(
                "Q1" => 604,
                "Q2" => 583,
                "Q3" => 490
            ),
            "Bread" => array(
                "Q1" => 38,
                "Q2" => 10,
                "Q3" => 50
            )
        ),
        "Item1" => array(
            "Milk" => array(
                "Q1" => 335,
                "Q2" => 684,
                "Q3" => 389
            ),
            "Egg" => array(
                "Q1" => 365,
                "Q2" => 490,
                "Q3" => 385
            ),
            "Bread" => array(
                "Q1" => 35,
                "Q2" => 48,
                "Q3" => 15
            )
        ),
        "Item2" => array(
            "Milk" => array(
                "Q1" => 336,
                "Q2" => 595,
                "Q3" => 366
            ),
            "Egg" => array(
                "Q1" => 484,
                "Q2" => 594,
                "Q3" => 385
            ),
            "Bread" => array(
                "Q1" => 80,
                "Q2" => 39,
                "Q3" => 20
            )
        )
    );

    echo '<h2><u>' . 'Multi Dimensional Array' . '</u></h2><br>';
    echo "<br><table border='1px' cellpadding='5px' cellspacing='0px'>";
    echo '<tr><th rowspan="3">Time</th><th colspan="3">Location = "Kolkata"</th>' . '<th colspan="3">Location = "Delhi"</th>' . '<th colspan="3">Location = "Mumbai"</th></tr>';
    echo '<tr><th colspan="3">Item</th>' . '<th colspan="3">Item</th>' . '<th colspan="3">Item</th></tr>';
    echo '<tr><th colspan="1">Milk</th><th colspan="1">Eggs</th><th colspan="1">Bread</th><th colspan="1">Milk</th><th colspan="1">Eggs</th><th colspan="1">Bread</th><th colspan="1">Milk</th><th colspan="1">Eggs</th><th colspan="1">Bread</th></tr>';
   
    foreach ($details as $key1 => $value1) {
        # code...
       
        //echo '<tr>';
        foreach ($value1 as $key2 => $value2) {
            # code...
           
            // echo '<th>' . $key2 ;
            foreach ($value2 as $key3 => $value3) {
            //     echo "<pre>";
            // print_r($value3);
            // echo "</pre>";
            echo '<td>' . $value3 . '</td>';
               
            }
           
        }
        echo '</tr>';
    }

    echo '</tr>';
    echo '</table>';
    ?>
</body>

</html>