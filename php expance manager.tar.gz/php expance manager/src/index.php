<?php
session_start();
?>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=>, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
</style>

<body>
    <h2>Daily Expence Manager</h2>
    <form action="" method="post">
        <label>Name</label>
        <input type="text" name="name">
        <select name="type_of_expance" required="required">
            <option> Grocery</option>
            <option> Veggies</option>
            <option> Travelling</option>
            <option> Miscellaneous</option>
        </select> <br> <br>
        <label>Quantity</label>
        <input type="text" name="quantity"> <br> <br>
        <label>Rate</label>
        <input type="text" name="Rate"> <br> <br>
        <label>Income</label>
        <input type="number" name="income" value="income"> <br> <br>
        <input type="submit" name="add" value="ADD">
        <hr>
    </form>
    <?php

    if (!isset($_SESSION['arr'])) {
        $_SESSION['arr'] = array();
    }

    $expance = $_POST['type_of_expance'];
    $name = $_POST['name'];
    $income = $_POST['income'];
    $quantity = $_POST['quantity'];
    $Rate = $_POST['Rate'];
    $total_expance = $quantity * $Rate;
    $balance = $income - $total_expance;

    $budge = array(
        "expance" => $expance,
        "name" => $name,
        "income" => $income,
        "total_expance" => $total_expance,
        "balance" => $balance,
    );
    // print_r($budge);
    array_push($_SESSION['arr'], $budge);
    echo "<table border='2px'>";
    echo "<tr>
        <th>Type</th>
        <th>Name</th>
        <th>Income</th>
        <th>Expance</th>
        <th>Balance</th>
        <th colspan='2'>Action</th>
           </tr>";
    foreach ($_SESSION['arr'] as $v1) {
        echo "<tr>";
        foreach ($v1 as $v2) {
            echo "<td> $v2 </td>";
        }
        echo "<td><button style='background-color:lightgreen'>Edit</button></td>";
        echo "<td><button style='background-color:#ff4d4d'>Delete</button></td>";
        echo "</tr>";  
    }
    echo "</table>";
    //    if($_SERVER['REQUEST_METHOD'] == 'POST'){ 
    ?>
</body>

</html>